<?php

namespace App\Controllers;

class Produk extends BaseController
{
    public function index()
    {
        return view('data_produk'); 
        
    }
}
